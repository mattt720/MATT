﻿using System.Windows;
using System.Windows.Input;

namespace ChoreManagementSystem
{
    //partial class declaration for the main window
    public partial class MainWindow : Window
    {
        //constructor for mainwindow
        public MainWindow()
        {
            //init
            InitializeComponent();
            //set the data context to an instance of MainWindowViewModel
            DataContext = new MainWindowViewModel();

            weeklyChoresDataGrid.PreviewTextInput += weeklyChoresDataGrid_PreviewTextInput;
        }

        //event handler for the PreviewTextInput event of the weeklyChoresDataGrid
        private void weeklyChoresDataGrid_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            //validate the input text using the ValidateEstimatedTime method from InputValidationUtil
            //if input is not valid, set e.Handled to true to prevent the input from being put forward
            e.Handled = !InputValidationUtil.ValidateEstimatedTime(e.Text, out _);
        }
    }
}
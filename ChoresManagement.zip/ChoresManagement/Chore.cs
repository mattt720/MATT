﻿using System.ComponentModel;

namespace ChoreManagementSystem
{
    public class Chore : INotifyPropertyChanged
    {
        //checks if chore has been ticked
        private bool _isChecked;
        public bool IsChecked
        {
            get { return _isChecked;}
            set
            {
                _isChecked = value;
                OnPropertyChanged(nameof(IsChecked));
            }
        }
        //name of chore
        private string? _name;
        public string Name
        {
            get {return _name;}
            set
            {
                _name = value;
                OnPropertyChanged(nameof(Name));
            }
        }
        //time for the chore
        private int _estimatedTime;
        public int EstimatedTime
        {
            get { return _estimatedTime;}
            set
            {
                _estimatedTime = value;
                OnPropertyChanged(nameof(EstimatedTime));
            }
        }
        //event for notifying property changes
        public event PropertyChangedEventHandler? PropertyChanged;

        //tells us when a property changes
        private void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
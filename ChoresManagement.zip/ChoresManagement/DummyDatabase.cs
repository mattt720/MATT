﻿//DummyDatabase.cs
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
namespace ChoreManagementSystem
{
    public static class DummyDatabase
    {
        //file path for storing the weekly chores data
        private static readonly string FilePath = "weekly_chores.json";
        public static void SaveWeeklyChores(List<Chore> weeklyChores)
        {
            //serialize the weekly chores list to JSON
            string jsonString = JsonSerializer.Serialize(weeklyChores, new JsonSerializerOptions { WriteIndented = true });
            //then write the JSON string to the file
            File.WriteAllText(FilePath, jsonString);
        }
        public static List<Chore> LoadWeeklyChores()
        {
            //check if file exists
            if (File.Exists(FilePath))
            {
                //read JSON string from the file
                string jsonString = File.ReadAllText(FilePath);
                //deserialize the JSON string to a list of chores
                return JsonSerializer.Deserialize<List<Chore>>(jsonString);
            }
            else
            {
                //if the file doesn't exist, return an empty list of chores
                return new List<Chore>();
            }
        }
    }
}
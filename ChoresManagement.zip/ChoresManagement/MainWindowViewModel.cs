﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;

namespace ChoreManagementSystem
{
    public class MainWindowViewModel : INotifyPropertyChanged
    {
        //collection of common chores
        public ObservableCollection<Chore> CommonChores { get; set; }

        //collection of weekly chores
        private ObservableCollection<Chore> _weeklyChores;
        public ObservableCollection<Chore> WeeklyChores
        {
            get { return _weeklyChores; }
            set
            {
                _weeklyChores = value;
                OnPropertyChanged(nameof(WeeklyChores));
                SaveWeeklyChores();
            }
        }

        //indicates if common chores can be added to weekly chores
        private bool _canAddToWeeklyChores;
        public bool CanAddToWeeklyChores
        {
            get { return _canAddToWeeklyChores; }
            set
            {
                _canAddToWeeklyChores = value;
                OnPropertyChanged(nameof(CanAddToWeeklyChores));
            }
        }

        //name of custom chore
        private string _customChoreName;
        public string CustomChoreName
        {
            get { return _customChoreName; }
            set
            {
                _customChoreName = value;
                OnPropertyChanged(nameof(CustomChoreName));
            }
        }

        //name of new common chore
        private string _newCommonChoreName;
        public string NewCommonChoreName
        {
            get { return _newCommonChoreName; }
            set
            {
                _newCommonChoreName = value;
                OnPropertyChanged(nameof(NewCommonChoreName));
            }
        }

        //commands for buttons
        public ICommand AddCheckedToWeeklyChoresCommand {get; private set;}
        public ICommand AddCustomChoreCommand {get; private set;}
        public ICommand ClearWeeklyChoresCommand {get; private set;}
        public ICommand AddCommonChoreCommand {get; private set;}
        public ICommand DeleteCheckedCommonChoresCommand {get; private set;}

        //event for notifying property changes
        public event PropertyChangedEventHandler? PropertyChanged;

        public MainWindowViewModel()
        {
            //init collections and load data
            CommonChores = new ObservableCollection<Chore>();
            _weeklyChores = new ObservableCollection<Chore>(DummyDatabase.LoadWeeklyChores());
            LoadCommonChores();

            //commands setup
            AddCheckedToWeeklyChoresCommand = new RelayCommand(AddCheckedToWeeklyChores);
            AddCustomChoreCommand = new RelayCommand(AddCustomChore, CanAddCustomChore);
            ClearWeeklyChoresCommand = new RelayCommand(ClearWeeklyChores);
            AddCommonChoreCommand = new RelayCommand(AddCommonChore, CanAddCommonChore);
            DeleteCheckedCommonChoresCommand = new RelayCommand(DeleteCheckedCommonChores, CanDeleteCheckedCommonChores);
        }

        //checks if a new common chore name is provided
        private bool CanAddCommonChore(object parameter)
        {
            return !string.IsNullOrWhiteSpace(NewCommonChoreName);
        }

        //adds a new common chore
        private void AddCommonChore(object parameter)
        {
            CommonChores.Add(new Chore { Name = NewCommonChoreName, EstimatedTime = 0 });
            NewCommonChoreName = string.Empty;
        }

        //checks if any common chore is checked
        private bool CanDeleteCheckedCommonChores(object parameter)
        {
            return CommonChores.Any(c => c.IsChecked);
        }

        //deletes checked common chores
        private void DeleteCheckedCommonChores(object parameter)
        {
            var checkedChores = CommonChores.Where(c => c.IsChecked).ToList();
            foreach (var chore in checkedChores)
            {
                CommonChores.Remove(chore);
            }
        }

        //saves weekly chores to the database
        private void SaveWeeklyChores()
        {
            DummyDatabase.SaveWeeklyChores(WeeklyChores.ToList());
            OnPropertyChanged(nameof(WeeklyChores));
        }

        //loads common chores
        private void LoadCommonChores()
        {
            CommonChores.Add(new Chore { Name = "Vacuum the carpets", EstimatedTime = 30 });
            CommonChores.Add(new Chore { Name = "Clean the bathroom", EstimatedTime = 45 });
            CommonChores.Add(new Chore { Name = "Do the dishes", EstimatedTime = 20 });
            CommonChores.Add(new Chore { Name = "Laundry", EstimatedTime = 60 });
        }

        //adds checked common chores to weekly chores
        private void AddCheckedToWeeklyChores(object parameter)
        {
            var checkedChores = CommonChores.Where(c => c.IsChecked).ToList();
            int count = 0;

            foreach (var chore in checkedChores)
            {
                if (!WeeklyChores.Any(c => c.Name == chore.Name))
                {
                    WeeklyChores.Add(new Chore { Name = chore.Name, EstimatedTime = chore.EstimatedTime });
                    count++;
                }
                chore.IsChecked = false;
            }

            if (count > 0)
            {
                MessageBox.Show($"{count} chore(s) added to the weekly chores list.");
            }
            else
            {
                MessageBox.Show("The checked chore(s) are already in the weekly chores list.");
            }

            SaveWeeklyChores();
        }

        //checks if a custom chore name is provided
        private bool CanAddCustomChore(object parameter)
        {
            return !string.IsNullOrWhiteSpace(CustomChoreName);
        }

        //adds a custom chore to weekly chores
        private void AddCustomChore(object parameter)
        {
            if (!string.IsNullOrWhiteSpace(CustomChoreName))
            {
                var dialog = new CustomChoreDialog();
                if (dialog.ShowDialog() == true)
                {
                    var estimatedTime = dialog.EstimatedTime;
                    if (estimatedTime >= 0)
                    {
                        WeeklyChores.Add(new Chore { Name = CustomChoreName, EstimatedTime = estimatedTime });
                        CustomChoreName = string.Empty;
                        MessageBox.Show($"Custom chore '{CustomChoreName}' added successfully!");
                    }
                    else
                    {
                        MessageBox.Show("Please enter a valid estimated time.");
                    }
                }
            }
            else
            {
                MessageBox.Show("Please enter a chore name.");
            }

            SaveWeeklyChores();
        }

        //notifies property change
        private void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        //clears weekly chores
        private void ClearWeeklyChores(object parameter)
        {
            WeeklyChores.Clear();
            SaveWeeklyChores();
        }
    }
}